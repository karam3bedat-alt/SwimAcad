import React, { useState, useMemo } from 'react';
import { useStudents, useUpdateStudent } from '../hooks/useStudents';
import { usePayments, useAddPayment, useDeletePayment, useUpdatePayment } from '../hooks/usePayments';
import { useSettings, useUpdateSettings } from '../hooks/useSettings';
import { generatePaymentMessage, calculateMonthlyFee, formatAmount, PAYMENT_CONFIG, PaymentConfig } from '../services/paymentService';
import { autoNotifier } from '../services/autoNotificationService';
import { createWhatsAppLink } from '../utils/whatsapp';
import { generatePaymentsPDF, generateDetailedFinancialReport } from '../services/pdfService';
import { 
  DollarSign, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  MessageCircle, 
  Send,
  Calendar,
  TrendingUp,
  Users,
  Bell,
  Download,
  Loader2,
  Settings,
  X,
  Save,
  Edit2,
  Trash2,
  History,
  Search,
  Star
} from 'lucide-react';
import toast from 'react-hot-toast';
import { cn, exportToExcel } from '../lib/utils';
import { Modal } from './Modal';
import { useAuth } from '../AuthContext';
import { format, isWithinInterval } from 'date-fns';

export const PaymentManager: React.FC = () => {
  const { isAdmin } = useAuth();
  const { data: students, isLoading: studentsLoading } = useStudents();
  const { mutate: updateStudent } = useUpdateStudent();
  const { data: payments, isLoading: paymentsLoading } = usePayments();
  const { mutate: addPayment } = useAddPayment();
  const { mutate: updatePayment } = useUpdatePayment();
  const { mutate: deletePayment } = useDeletePayment();
  const { data: appSettings, isLoading: settingsLoading } = useSettings();
  const { mutate: updateSettings } = useUpdateSettings();
  
  const [selectedMonth, setSelectedMonth] = useState(
    new Date().toLocaleString('ar-EG', { month: 'long', year: 'numeric' })
  );
  const [isCustomRange, setIsCustomRange] = useState(false);
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [activeTab, setActiveTab] = useState<'overview' | 'pending' | 'paid' | 'history' | 'auto'>('overview');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [editingPayment, setEditingPayment] = useState<any>(null);
  const [confirmingPayment, setConfirmingPayment] = useState<any>(null);
  const [isNewPaymentOpen, setIsNewPaymentOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Local settings state for the form
  const [tempSettings, setTempSettings] = useState(PAYMENT_CONFIG);

  // Sync temp settings when appSettings loads
  React.useEffect(() => {
    if (appSettings?.payment_config) {
      setTempSettings(appSettings.payment_config);
    }
  }, [appSettings]);

  const currentConfig = (appSettings?.payment_config || PAYMENT_CONFIG) as PaymentConfig;

  // Arabic Months
  const arabicMonths = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
  ];

  // Calculate Stats
  // Students with status
  const studentsWithStatus = useMemo(() => {
    if (!students) return [];
    
    return students.map(student => {
      // Find all payments for this student in the selected month/range
      const studentPayments = payments?.filter(p => {
        if (!p || !p.date) return false;
        if (p.student_id !== student.id) return false;

        const pDate = new Date(p.date);

        if (isCustomRange && customStartDate && customEndDate) {
          try {
            const start = new Date(customStartDate);
            const end = new Date(customEndDate);
            end.setHours(23, 59, 59, 999);
            return pDate >= start && pDate <= end;
          } catch (e) {
            return false;
          }
        }
        
        const pMonthStr = pDate?.toLocaleString('ar-EG', { month: 'long', year: 'numeric' }) || '';
        const selectedMonthTrimmed = selectedMonth.trim();
        return pMonthStr.trim() === selectedMonthTrimmed || (p.month && p.month.trim() === selectedMonthTrimmed);
      }) || [];
      
      const totalPaid = studentPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      
      // Calculate requirement logic: 
      // 1. Try to find a stored required_amount in the payments for this period
      // 2. Fallback to calculation based on current course_type
      const storedRequiredAmount = Math.max(...studentPayments.filter(p => p.required_amount).map(p => Number(p.required_amount) || 0), 0);
      
      let baseAmount = student.custom_fee || calculateMonthlyFee(student.course_type || student.level, currentConfig.coursePrices);
      
      // Loyalty discount: If scholar has >= 100 points, they get a discount (e.g., 100 NIS)
      const hasLoyaltyDiscount = (student.loyalty_points || 0) >= 100;
      const calculatedRequiredAmount = hasLoyaltyDiscount ? Math.max(0, baseAmount - 100) : baseAmount;

      const requiredAmount = storedRequiredAmount > 0 ? storedRequiredAmount : calculatedRequiredAmount;

      const dueDate = isCustomRange && customStartDate ? new Date(customStartDate) : new Date();
      if (!isCustomRange) dueDate.setDate(1);
      
      const today = new Date();
      const daysOverdue = totalPaid >= requiredAmount ? 0 : 
        Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));

      let status: 'confirmed' | 'partial' | 'pending' = 'pending';
      const tolerance = 0.5;
      if (totalPaid >= requiredAmount - tolerance && requiredAmount > 0) status = 'confirmed';
      else if (totalPaid > 0.01) status = 'partial';

      return {
        ...student,
        requiredAmount,
        totalPaid,
        remainingAmount: Math.max(0, requiredAmount - totalPaid),
        status,
        paymentDate: studentPayments.length > 0 ? studentPayments[studentPayments.length - 1].date : undefined,
        paymentMethod: studentPayments.length > 0 ? studentPayments[studentPayments.length - 1].method : undefined,
        daysOverdue: Math.max(0, daysOverdue),
        receiptNumber: studentPayments.length > 0 ? studentPayments[studentPayments.length - 1].id : undefined
      };
    });
  }, [students, payments, selectedMonth, currentConfig.coursePrices, isCustomRange, customStartDate, customEndDate]);

  const stats = useMemo(() => {
    const total = studentsWithStatus.length;
    const paid = studentsWithStatus.filter(s => s.status === 'confirmed').length;
    const partial = studentsWithStatus.filter(s => s.status === 'partial').length;
    const pending = studentsWithStatus.filter(s => s.status === 'pending').length;
    const overdue = studentsWithStatus.filter(s => s.daysOverdue > 5).length;
    const revenue = studentsWithStatus.reduce((sum, s) => sum + s.totalPaid, 0);
    const expected = studentsWithStatus.reduce((sum, s) => sum + s.requiredAmount, 0);
    
    return { total, paid, partial, pending, overdue, revenue, expected };
  }, [studentsWithStatus]);

  // Send payment request
  const sendPaymentRequest = (student: any, type: 'due' | 'overdue' | 'reminder' | 'confirmed' = 'due') => {
    const message = generatePaymentMessage(student, student.amount, selectedMonth, type, currentConfig);
    const link = createWhatsAppLink(student.phone || student.parent_phone || '', message);
    window.open(link, '_blank');
    toast.success(`تم إرسال طلب دفع لـ ${student.full_name}`);
  };

  // Confirm payment receipt
  const confirmPayment = async (student: any) => {
    setConfirmingPayment(student);
  };

  // Send bulk requests
  const sendBulkRequest = () => {
    const pending = studentsWithStatus.filter(s => s.status === 'pending');
    
    if (pending.length === 0) {
      toast.error('لا توجد مدفوعات معلقة');
      return;
    }

    setIsProcessing(true);
    
    pending.forEach((student, index) => {
      setTimeout(() => {
        const type = student.daysOverdue > 5 ? 'overdue' : 'due';
        sendPaymentRequest(student, type);
      }, index * 3000);
    });

    setTimeout(() => setIsProcessing(false), pending.length * 3000);
    toast.success(`جاري إرسال ${pending.length} طلب دفع...`);
  };

  // Enable auto reminders
  const enableAutoReminders = () => {
    const notifications = autoNotifier.generateMonthlyNotifications(
      students || [], 
      payments || [], 
      selectedMonth,
      currentConfig
    );
    
    toast.success(`تمت جدولة ${notifications.length} تذكير تلقائي`);
  };

  // Export report
  const exportReport = () => {
    const reportData = studentsWithStatus.map(s => ({
      'اسم الطالب': s.full_name,
      'رقم الهاتف': s.phone || s.parent_phone || '-',
      'المستوى': s.level || '-',
      'نوع الدورة': s.course_type || '-',
      'المبلغ المطلوب (₪)': s.requiredAmount,
      'المبلغ المدفوع (₪)': s.totalPaid,
      'المتبقي (₪)': s.remainingAmount,
      'الحالة': s.status === 'confirmed' ? 'تم الدفع' : s.status === 'partial' ? 'دفع جزئي' : 'معلق',
      'تاريخ آخر دفعة': s.paymentDate ? new Date(s.paymentDate).toLocaleDateString('ar-EG') : '-',
      'طريقة الدفع': s.paymentMethod || '-'
    }));

    const periodLabel = isCustomRange 
      ? `الفترة_من_${customStartDate}_إلى_${customEndDate}`
      : selectedMonth.replace(' ', '_');

    exportToExcel(reportData, `تقرير_تحصيل_${periodLabel}`);
    toast.success('تم تصدير تقرير التحصيل بصيغة Excel');
  };

  if (studentsLoading || paymentsLoading || settingsLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
        <Loader2 className="animate-spin text-blue-600" size={48} />
        <p className="text-slate-500 font-medium">جاري تحميل بيانات المدفوعات...</p>
      </div>
    );
  }

  const handleSaveSettings = () => {
    updateSettings({ payment_config: tempSettings });
    setIsSettingsOpen(false);
    toast.success('تم حفظ إعدادات الدفع بنجاح');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-3 text-slate-900 dark:text-slate-100">
            <DollarSign className="text-emerald-600" size={32} />
            إدارة المدفوعات والتحصيل
          </h2>
          <p className="text-slate-500 dark:text-slate-400">متابعة الاشتراكات الشهرية وتنبيه المتأخرين.</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-2">
          {isAdmin && (
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
              title="إعدادات الدفع"
            >
              <Settings size={24} />
            </button>
          )}

          <button 
            onClick={() => setIsCustomRange(!isCustomRange)}
            className={cn(
              "px-4 py-2 rounded-xl text-xs font-bold transition-all border",
              isCustomRange 
                ? "bg-blue-600 text-white border-blue-600" 
                : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800"
            )}
          >
            {isCustomRange ? 'إلغاء المخصص' : 'تاريخ مخصص'}
          </button>

          {!isCustomRange ? (
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2 text-slate-700 dark:text-slate-200 outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
            >
              {arabicMonths.map(m => {
                const year = new Date().getFullYear();
                const monthYear = `${m} ${year}`;
                return (
                  <option key={monthYear} value={monthYear}>{monthYear}</option>
                );
              })}
            </select>
          ) : (
            <div className="flex items-center gap-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-2 py-1">
              <input 
                type="date"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                className="bg-transparent border-none outline-none text-xs font-bold text-slate-700 dark:text-slate-200 p-1"
              />
              <span className="text-slate-400 text-xs">إلى</span>
              <input 
                type="date"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                className="bg-transparent border-none outline-none text-xs font-bold text-slate-700 dark:text-slate-200 p-1"
              />
            </div>
          )}
          
          <button
            onClick={exportReport}
            className="bg-emerald-600 text-white px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 dark:shadow-none"
          >
            <Download size={18} />
            تصدير Excel
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <StatCard 
          icon={Users} 
          label="إجمالي الطلاب" 
          value={stats.total} 
          color="blue" 
        />
        <StatCard 
          icon={CheckCircle} 
          label="تم الدفع" 
          value={stats.paid} 
          color="green" 
        />
        <StatCard 
          icon={Clock} 
          label="معلق" 
          value={stats.pending} 
          color="yellow" 
        />
        <StatCard 
          icon={AlertTriangle} 
          label="متأخر" 
          value={stats.overdue} 
          color="red" 
        />
        <StatCard 
          icon={TrendingUp} 
          label="الإيرادات" 
          value={formatAmount(stats.revenue)} 
          color="purple" 
        />
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-4 overflow-x-auto custom-scrollbar">
        {[
          { id: 'overview', label: 'نظرة عامة', icon: Calendar },
          { id: 'pending', label: 'المعلقون', icon: Clock },
          { id: 'paid', label: 'تم الدفع', icon: CheckCircle },
          { id: 'history', label: 'سجل الدفعات', icon: History },
          { id: 'auto', label: 'تذكيرات تلقائية', icon: Bell },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "flex items-center gap-2 px-4 py-3 border-b-2 transition-all whitespace-nowrap font-bold",
              activeTab === tab.id 
                ? 'border-blue-600 text-blue-600' 
                : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            )}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Actions Bar */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => setIsNewPaymentOpen(true)}
          className="bg-purple-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-purple-700 shadow-lg shadow-purple-100 dark:shadow-none transition-all"
        >
          <DollarSign size={20} />
          دفعة جديدة بمبلغ مخصص
        </button>

        <button
          onClick={sendBulkRequest}
          disabled={isProcessing || stats.pending === 0}
          className="bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-700 disabled:opacity-50 shadow-lg shadow-emerald-100 dark:shadow-none transition-all"
        >
          {isProcessing ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} />}
          {isProcessing ? 'جاري الإرسال...' : `إرسال طلبات للجميع (${stats.pending})`}
        </button>
        
        <button
          onClick={enableAutoReminders}
          className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-blue-700 shadow-lg shadow-blue-100 dark:shadow-none transition-all"
        >
          <Bell size={20} />
          تفعيل التذكيرات التلقائية
        </button>
        
        <button
          onClick={() => autoNotifier.checkAndSend()}
          className="bg-orange-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-orange-700 shadow-lg shadow-orange-100 dark:shadow-none transition-all"
        >
          <MessageCircle size={20} />
          فحص وإرسال فوري
        </button>
      </div>

      {/* Content */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        {activeTab === 'overview' && (
          <OverviewTab students={studentsWithStatus} onSend={sendPaymentRequest} onConfirm={confirmPayment} />
        )}
        {activeTab === 'pending' && (
          <PendingTab students={studentsWithStatus.filter(s => s.status === 'pending')} onSend={sendPaymentRequest} />
        )}
        {activeTab === 'paid' && (
          <PaidTab students={studentsWithStatus.filter(s => s.status === 'confirmed')} />
        )}
        {activeTab === 'history' && (
          <HistoryTab 
            payments={payments} 
            onEdit={(p: any) => setEditingPayment(p)}
            onDelete={(id: string) => {
              if (window.confirm('هل أنت متأكد من حذف هذا السجل المالي؟')) {
                deletePayment(id);
                toast.success('تم حذف السجل بنجاح');
              }
            }}
          />
        )}
        {activeTab === 'auto' && (
          <AutoTab stats={autoNotifier.getStats()} />
        )}
      </div>

      {/* Edit Payment Modal */}
      <Modal
        isOpen={!!editingPayment}
        onClose={() => setEditingPayment(null)}
        title="تعديل سجل مالي"
      >
        {editingPayment && (
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            updatePayment({ 
              id: editingPayment.id, 
              data: { 
                amount: Number(formData.get('amount')),
                required_amount: Number(formData.get('required_amount')),
                month: formData.get('month') as string,
                method: formData.get('method') as string,
                date: formData.get('date') as string,
                notes: formData.get('notes') as string
              }
            });
            setEditingPayment(null);
            toast.success('تم تحديث السجل المالي');
          }} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2 col-span-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">اسم الطالب</label>
                <input type="text" disabled value={editingPayment.student_name} className="w-full bg-slate-100 dark:bg-slate-800 rounded-xl px-4 py-2 opacity-60" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">المبلغ المستلم (₪)</label>
                <input name="amount" type="number" defaultValue={editingPayment.amount} required className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">المبلغ المطلوب (₪)</label>
                <input name="required_amount" type="number" defaultValue={editingPayment.required_amount} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">الشهر</label>
                <input name="month" type="text" defaultValue={editingPayment.month} required className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">طريقة الدفع</label>
                <select name="method" defaultValue={editingPayment.method} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2">
                  <option value="نقدي">نقدي</option>
                  <option value="Bit">Bit</option>
                  <option value="PayBox">PayBox</option>
                  <option value="تحويل بنكي">تحويل بنكي</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">التاريخ</label>
              <input name="date" type="datetime-local" defaultValue={editingPayment.date ? new Date(editingPayment.date).toISOString().slice(0, 16) : ''} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2" />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">ملاحظات</label>
              <textarea name="notes" defaultValue={editingPayment.notes} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 h-20 text-sm" />
            </div>

            <div className="flex gap-3 pt-4">
              <button type="submit" className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700">
                <Save size={20} /> حفظ التعديلات
              </button>
              <button type="button" onClick={() => setEditingPayment(null)} className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 py-3 rounded-xl font-bold">إلغاء</button>
            </div>
          </form>
        )}
      </Modal>

      {/* Confirmation Modal */}
      <Modal
        isOpen={!!confirmingPayment}
        onClose={() => setConfirmingPayment(null)}
        title="تسجيل عملية دفع"
      >
        {confirmingPayment && (
          <form onSubmit={async (e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const amount = Number(formData.get('amount'));
            const method = formData.get('method') as string;
            const type = formData.get('type') as string;
            const courseType = formData.get('course_type') as string;
            const notes = formData.get('notes') as string;
            
            try {
              setIsProcessing(true);
              const currentPoints = confirmingPayment.loyalty_points || 0;
              
              let paymentNotes = notes || '';
              let usedDiscount = false;

              if (type === 'subscription') {
                usedDiscount = currentPoints >= 100;
                if (usedDiscount) {
                  paymentNotes = (paymentNotes ? paymentNotes + ' - ' : '') + 'تم استخدام خصم الولاء (100 شيقل)';
                }
              }

              const newPoints = usedDiscount ? (currentPoints - 100 + 10) : (currentPoints + 10);

              await addPayment({
                student_id: confirmingPayment.id,
                student_name: confirmingPayment.full_name,
                amount: amount,
                method: method,
                month: selectedMonth,
                course_type: type === 'subscription' ? courseType : (type === 'product' ? 'منتجات' : 'دفعة مخصصة'),
                required_amount: type === 'subscription' ? confirmingPayment.requiredAmount : amount,
                date: new Date().toISOString(),
                notes: paymentNotes
              });

              // Update Student if subscription
              if (type === 'subscription') {
                await updateStudent({
                  id: confirmingPayment.id,
                  data: { 
                    course_type: courseType,
                    loyalty_points: newPoints
                  }
                });
              }

              const receiptNum = `REC-${Date.now()}-${confirmingPayment.id}`;
              const message = generatePaymentMessage(
                { ...confirmingPayment, receiptNumber: receiptNum, course_type: courseType }, 
                amount, 
                selectedMonth, 
                'confirmed',
                currentConfig
              );
              
              const link = createWhatsAppLink(confirmingPayment.phone || confirmingPayment.parent_phone || '', message);
              window.open(link, '_blank');
              
              toast.success(`✅ تم تسجيل الدفعة لـ ${confirmingPayment.full_name}`);
              setConfirmingPayment(null);
            } catch (err) {
              toast.error('فشل تسجيل الدفعة');
            } finally {
              setIsProcessing(false);
            }
          }} className="space-y-4">
            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
              <p className="text-sm font-bold text-slate-700 dark:text-slate-200">الاسم: {confirmingPayment.full_name}</p>
              <p className="text-xs text-slate-500 mt-1">النقاط المتوفرة: {confirmingPayment.loyalty_points || 0}</p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold block text-right">خيار الدفع</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'subscription', label: 'تجديد اشتراك' },
                  { id: 'product', label: 'شراء منتج' },
                  { id: 'custom', label: 'دفعة مخصصة' }
                ].map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => {
                      // Update local state by re-setting confirmingPayment with type
                      setConfirmingPayment({ ...confirmingPayment, paymentType: t.id });
                    }}
                    className={cn(
                      "py-2 px-1 rounded-xl text-xs font-bold border transition-all",
                      (confirmingPayment.paymentType || 'subscription') === t.id
                        ? "bg-blue-600 border-blue-600 text-white shadow-md"
                        : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600"
                    )}
                  >
                    <input type="hidden" name="type" value={confirmingPayment.paymentType || 'subscription'} />
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {(confirmingPayment.paymentType === 'subscription' || !confirmingPayment.paymentType) && (
                <div className="space-y-2">
                  <label className="text-sm font-bold">نوع الدورة</label>
                  <select name="course_type" defaultValue={confirmingPayment.course_type} className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2 text-sm">
                    {Object.keys(currentConfig.coursePrices).map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
              )}
              <div className={cn("space-y-2", (confirmingPayment.paymentType !== 'subscription' && confirmingPayment.paymentType) ? "col-span-2" : "")}>
                <label className="text-sm font-bold">المبلغ المستلم (₪)</label>
                <input 
                  name="amount" 
                  type="number" 
                  defaultValue={confirmingPayment.paymentType === 'subscription' ? confirmingPayment.requiredAmount : 0} 
                  required 
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2 font-bold text-center" 
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold">طريقة الدفع</label>
              <select name="method" className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2 text-sm">
                <option value="نقدي">نقدي</option>
                <option value="Bit">Bit</option>
                <option value="PayBox">PayBox</option>
                <option value="تحويل بنكي">تحويل بنكي</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold">ملاحظات (اختياري)</label>
              <input name="notes" placeholder="أدخل أي ملاحظات إضافية..." className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2 text-sm" />
            </div>

            <div className="flex gap-3 pt-4">
              <button type="submit" disabled={isProcessing} className="flex-1 bg-blue-600 text-white py-4 rounded-xl font-black flex items-center justify-center gap-2 hover:bg-blue-700 disabled:opacity-50 transition-all">
                {isProcessing ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                تأكيد الدفع
              </button>
              <button type="button" onClick={() => setConfirmingPayment(null)} className="px-6 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 py-4 rounded-xl font-bold">إلغاء</button>
            </div>
          </form>
        )}
      </Modal>

      {/* New Custom Payment Modal */}
      <Modal
        isOpen={isNewPaymentOpen}
        onClose={() => setIsNewPaymentOpen(false)}
        title="تسجيل دفعة جديدة بمبلغ مخصص"
      >
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute right-3 top-3 text-slate-400" size={20} />
            <input
              type="text"
              placeholder="ابحث عن الطالب بالاسم..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pr-10 pl-4 py-3 outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="max-h-48 overflow-y-auto space-y-2 custom-scrollbar">
            {students?.filter(s => s.full_name.includes(searchQuery)).slice(0, 5).map(s => (
              <button
                key={s.id}
                onClick={() => {
                  setConfirmingPayment({
                    ...s,
                    amount: 0, // Let them enter custom amount
                    course_type: s.course_type || s.level,
                    status: 'pending',
                    loyalty_points: s.loyalty_points || 0
                  });
                  setIsNewPaymentOpen(false);
                  setSearchQuery('');
                }}
                className="w-full text-right p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-all flex justify-between items-center"
              >
                <div>
                  <p className="font-bold text-slate-900 dark:text-slate-100">{s.full_name}</p>
                  <p className="text-xs text-slate-500">{s.level}</p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-900/20 text-blue-600 px-3 py-1 rounded-lg text-xs font-bold">اختيار</div>
              </button>
            ))}
            {searchQuery && students?.filter(s => s.full_name.includes(searchQuery)).length === 0 && (
              <p className="text-center py-4 text-slate-500 text-sm">لم يتم العثور على نتائج</p>
            )}
          </div>
        </div>
      </Modal>

      {/* Settings Modal */}
      <Modal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        title="إعدادات الدفع والتحصيل"
      >
        <div className="space-y-4 p-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">اسم الأكاديمية</label>
              <input
                type="text"
                value={tempSettings.academyName}
                onChange={(e) => setTempSettings({ ...tempSettings, academyName: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-blue-500 dark:text-slate-100"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">هاتف الأكاديمية</label>
              <input
                type="text"
                value={tempSettings.academyPhone}
                onChange={(e) => setTempSettings({ ...tempSettings, academyPhone: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-blue-500 dark:text-slate-100"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">رقم Bit</label>
              <input
                type="text"
                value={tempSettings.bitPhone}
                onChange={(e) => setTempSettings({ ...tempSettings, bitPhone: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-blue-500 dark:text-slate-100"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">رقم PayBox</label>
              <input
                type="text"
                value={tempSettings.payboxPhone}
                onChange={(e) => setTempSettings({ ...tempSettings, payboxPhone: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-blue-500 dark:text-slate-100"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">اسم البنك</label>
              <input
                type="text"
                value={tempSettings.bankName}
                onChange={(e) => setTempSettings({ ...tempSettings, bankName: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-blue-500 dark:text-slate-100"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">رقم الحساب البنكي</label>
              <input
                type="text"
                value={tempSettings.bankAccount}
                onChange={(e) => setTempSettings({ ...tempSettings, bankAccount: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-blue-500 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-700">
            <h4 className="font-bold text-slate-900 dark:text-slate-100">أسعار الدورات (₪)</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(tempSettings.coursePrices || {}).map(([course, price]) => (
                <div key={course} className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 truncate block" title={course}>{course}</label>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setTempSettings({
                      ...tempSettings,
                      coursePrices: {
                        ...tempSettings.coursePrices,
                        [course]: Number(e.target.value)
                      }
                    })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-blue-500 dark:text-slate-100"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <button
              onClick={handleSaveSettings}
              className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-all"
            >
              <Save size={20} />
              حفظ الإعدادات
            </button>
            <button
              onClick={() => setIsSettingsOpen(false)}
              className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 py-3 rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
            >
              إلغاء
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

// Sub-components
const StatCard = ({ icon: Icon, label, value, color }: { icon: any, label: string, value: string | number, color: string }) => {
  const colors: Record<string, string> = {
    blue: 'bg-blue-50 dark:bg-blue-900/10 text-blue-600 dark:text-blue-400 border-blue-100 dark:border-blue-800/30',
    green: 'bg-emerald-50 dark:bg-emerald-900/10 text-emerald-600 dark:text-emerald-400 border-emerald-100 dark:border-emerald-800/30',
    yellow: 'bg-amber-50 dark:bg-amber-900/10 text-amber-600 dark:text-amber-400 border-amber-100 dark:border-amber-800/30',
    red: 'bg-rose-50 dark:bg-rose-900/10 text-rose-600 dark:text-rose-400 border-rose-100 dark:border-rose-800/30',
    purple: 'bg-purple-50 dark:bg-purple-900/10 text-purple-600 dark:text-purple-400 border-purple-100 dark:border-purple-800/30'
  };

  return (
    <div className={cn("p-4 rounded-2xl border transition-all", colors[color])}>
      <div className="flex items-center gap-2 mb-2">
        <Icon size={18} />
        <span className="text-xs font-bold opacity-80">{label}</span>
      </div>
      <p className="text-xl font-bold">{value}</p>
    </div>
  );
};

const OverviewTab = ({ students, onSend, onConfirm }: { students: any[], onSend: any, onConfirm: any }) => (
  <div className="bg-white dark:bg-slate-900 overflow-hidden">
    {/* Table View - Hidden on Mobile */}
    <div className="hidden lg:block overflow-x-auto">
      <table className="w-full text-right">
        <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800">
          <tr>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">الطالب</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">المستوى</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">المبلغ المطلوب</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">المبلغ المدفوع</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">الحالة</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">التأخير</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">الإجراءات</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
          {students.map(student => (
            <tr key={student.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
              <td className="px-6 py-4">
                <p className="font-bold text-slate-900 dark:text-slate-100">{student.full_name}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{student.phone || student.parent_phone}</p>
              </td>
              <td className="px-6 py-4 text-sm text-slate-600 dark:text-slate-400">{student.level}</td>
              <td className="px-6 py-4 font-bold text-slate-900 dark:text-slate-100">
                {formatAmount(student.requiredAmount)}
                {(student.loyalty_points || 0) >= 100 && (
                  <span className="block text-[10px] text-emerald-600 font-bold">خصم ولاء ✨</span>
                )}
              </td>
              <td className="px-6 py-4">
                <span className={cn("font-bold", student.totalPaid > 0 ? "text-emerald-600" : "text-slate-400")}>
                  {formatAmount(student.totalPaid)}
                </span>
                {student.remainingAmount > 0 && (
                  <span className={cn(
                    "block text-[10px] font-bold",
                    student.totalPaid > 0 ? "text-rose-600" : "text-slate-400"
                  )}>
                    {student.totalPaid > 0 ? `باقي: ${formatAmount(student.remainingAmount)}` : `مطلوب: ${formatAmount(student.remainingAmount)}`}
                  </span>
                )}
              </td>
              <td className="px-6 py-4">
                <StatusBadge status={student.status} daysOverdue={student.daysOverdue} />
              </td>
              <td className="px-6 py-4">
                {student.daysOverdue > 0 ? (
                  <span className="text-rose-600 dark:text-rose-400 font-bold">{student.daysOverdue} يوم</span>
                ) : (
                  <span className="text-slate-400 dark:text-slate-600">-</span>
                )}
              </td>
              <td className="px-6 py-4">
                <div className="flex gap-2">
                  {student.status !== 'confirmed' ? (
                    <>
                      <button
                        onClick={() => onSend(student, student.daysOverdue > 5 ? 'overdue' : 'due')}
                        className="bg-blue-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-blue-600 transition-colors"
                      >
                        تذكير
                      </button>
                      <button
                        onClick={() => onConfirm(student)}
                        className="bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-emerald-600 transition-colors"
                      >
                        دفع
                      </button>
                    </>
                  ) : (
                    <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1 text-sm font-bold">
                      <CheckCircle size={16} /> مكتمل
                    </span>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>

    {/* Mobile Card View */}
    <div className="lg:hidden divide-y divide-slate-100 dark:divide-slate-800">
      {students.map(student => (
        <div key={student.id} className="p-4 space-y-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="font-bold text-slate-900 dark:text-slate-100">{student.full_name}</p>
              <p className="text-xs text-slate-500">{student.phone || student.parent_phone}</p>
            </div>
            <StatusBadge status={student.status} daysOverdue={student.daysOverdue} />
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="bg-slate-50 dark:bg-slate-800/50 p-2 rounded-xl">
              <p className="text-[10px] text-slate-400 mb-1">المبلغ المطلوب</p>
              <p className="font-bold text-slate-900 dark:text-slate-100">{formatAmount(student.requiredAmount)}</p>
              {(student.loyalty_points || 0) >= 100 && (
                <span className="text-[10px] text-emerald-600 font-bold">خصم ولاء ✨</span>
              )}
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/50 p-2 rounded-xl">
              <p className="text-[10px] text-slate-400 mb-1">المدفوع / المتبقي</p>
              <p className={cn("font-bold", student.totalPaid > 0 ? "text-emerald-600" : "text-slate-900")}>
                {formatAmount(student.totalPaid)}
              </p>
              {student.remainingAmount > 0 && (
                <p className="text-[10px] text-rose-600 font-bold">
                   المتبقي: {formatAmount(student.remainingAmount)}
                </p>
              )}
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl flex justify-between items-center">
            <p className="text-xs font-bold text-slate-500">نقاط الولاء</p>
            <p className="font-bold text-amber-600 flex items-center gap-1">
              {student.loyalty_points || 0} <Star size={14} />
            </p>
          </div>

          {student.status === 'pending' && (
            <div className="flex gap-2 pt-2 border-t border-slate-50 dark:border-slate-800">
              <button
                onClick={() => onSend(student, student.daysOverdue > 5 ? 'overdue' : 'due')}
                className="flex-1 bg-blue-600 text-white py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-blue-100"
              >
                طلب دفع
              </button>
              <button
                onClick={() => onConfirm(student)}
                className="flex-1 bg-emerald-600 text-white py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-emerald-100"
              >
                تأكيد الاستلام
              </button>
            </div>
          )}
          {student.status === 'confirmed' && (
            <div className="pt-2 border-t border-slate-50 dark:border-slate-800 text-center">
              <span className="text-emerald-600 font-bold text-sm flex items-center justify-center gap-2">
                <CheckCircle size={18} /> تم استلام الدفعة
              </span>
            </div>
          )}
        </div>
      ))}
    </div>
  </div>
);

const PendingTab = ({ students, onSend }: { students: any[], onSend: any }) => (
  <div className="p-6">
    <h3 className="text-lg font-bold mb-6 text-slate-900 dark:text-slate-100">مدفوعات معلقة ({students.length})</h3>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {students.map(student => (
        <div key={student.id} className="border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
          <div>
            <p className="font-bold text-lg text-slate-900 dark:text-slate-100">{student.full_name}</p>
            <p className="text-slate-600 dark:text-slate-400 text-sm">{student.level} - {formatAmount(student.amount)}</p>
            {student.daysOverdue > 0 && (
              <p className="text-rose-600 dark:text-rose-400 text-xs font-bold mt-1">متأخر {student.daysOverdue} يوم</p>
            )}
          </div>
          <button
            onClick={() => onSend(student, student.daysOverdue > 5 ? 'overdue' : 'due')}
            className="bg-emerald-600 text-white px-4 py-2 rounded-xl flex items-center gap-2 font-bold text-sm hover:bg-emerald-700 transition-all"
          >
            <MessageCircle size={18} />
            تذكير
          </button>
        </div>
      ))}
      {students.length === 0 && (
        <div className="col-span-2 text-center py-12 text-slate-500 dark:text-slate-400">
          لا توجد مدفوعات معلقة حالياً.
        </div>
      )}
    </div>
  </div>
);

const PaidTab = ({ students }: { students: any[] }) => (
  <div className="p-6">
    <h3 className="text-lg font-bold mb-6 text-slate-900 dark:text-slate-100">مدفوعات تم استلامها ({students.length})</h3>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {students.map(student => (
        <div key={student.id} className="border border-emerald-100 dark:border-emerald-900/30 rounded-2xl p-4 bg-emerald-50 dark:bg-emerald-900/10">
          <div className="flex justify-between items-center">
            <div>
              <p className="font-bold text-lg text-slate-900 dark:text-slate-100">{student.full_name}</p>
              <p className="text-slate-600 dark:text-slate-400 text-sm">{formatAmount(student.amount)}</p>
            </div>
            <div className="text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
              <CheckCircle size={24} />
              <span className="font-bold">تم الدفع</span>
            </div>
          </div>
          {student.receiptNumber && (
            <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-2">رقم المرجع: {student.receiptNumber}</p>
          )}
        </div>
      ))}
      {students.length === 0 && (
        <div className="col-span-2 text-center py-12 text-slate-500 dark:text-slate-400">
          لم يتم تسجيل أي مدفوعات لهذا الشهر بعد.
        </div>
      )}
    </div>
  </div>
);

const AutoTab = ({ stats }: { stats: any }) => (
  <div className="p-6 space-y-8">
    <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">نظام التذكيرات التلقائي</h3>
    
    <div className="grid grid-cols-3 gap-6">
      <div className="bg-blue-50 dark:bg-blue-900/10 p-6 rounded-2xl text-center border border-blue-100 dark:border-blue-800/30">
        <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">{stats.scheduled}</p>
        <p className="text-slate-600 dark:text-slate-400 text-sm font-bold">مجدولة</p>
      </div>
      <div className="bg-emerald-50 dark:bg-emerald-900/10 p-6 rounded-2xl text-center border border-emerald-100 dark:border-emerald-800/30">
        <p className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">{stats.sent}</p>
        <p className="text-slate-600 dark:text-slate-400 text-sm font-bold">تم الإرسال</p>
      </div>
      <div className="bg-amber-50 dark:bg-amber-900/10 p-6 rounded-2xl text-center border border-amber-100 dark:border-amber-800/30">
        <p className="text-3xl font-bold text-amber-600 dark:text-amber-400">{stats.pending}</p>
        <p className="text-slate-600 dark:text-slate-400 text-sm font-bold">معلقة</p>
      </div>
    </div>

    <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
      <h4 className="font-bold mb-4 text-slate-900 dark:text-slate-100 flex items-center gap-2">
        <Bell size={18} className="text-blue-600" />
        كيف يعمل النظام؟
      </h4>
      <ul className="space-y-3 text-slate-600 dark:text-slate-400 text-sm">
        <li className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-1.5 flex-shrink-0" />
          <span>قبل 3 أيام من موعد الاستحقاق - يتم إرسال تذكير لطيف لولي الأمر.</span>
        </li>
        <li className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-1.5 flex-shrink-0" />
          <span>بعد 5 أيام من التأخير - يتم إرسال تنبيه عاجل بضرورة السداد.</span>
        </li>
        <li className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-1.5 flex-shrink-0" />
          <span>يتم فتح محادثة الواتساب تلقائياً مع الرسالة المجهزة لتسهيل التواصل.</span>
        </li>
      </ul>
    </div>
  </div>
);

const HistoryTab = ({ payments, onEdit, onDelete }: { payments: any[], onEdit: any, onDelete: any }) => (
  <div className="p-6">
    <div className="flex justify-between items-center mb-6">
      <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">سجل المدفوعات التاريخي</h3>
      <p className="text-sm text-slate-500">إجمالي السجلات: {payments.length}</p>
    </div>
    
    <div className="overflow-x-auto">
      <table className="w-full text-right">
        <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800">
          <tr>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">الطالب</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">المبلغ المستلم</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">المطلوب</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">الشهر</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">الطريقة</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">التاريخ</th>
            <th className="px-6 py-4 text-sm font-bold text-slate-600 dark:text-slate-400 text-right">الإجراءات</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
          {payments.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(payment => (
            <tr key={payment.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
              <td className="px-6 py-4 font-bold text-slate-900 dark:text-slate-100">{payment.student_name}</td>
              <td className="px-6 py-4 font-bold text-emerald-600">{formatAmount(payment.amount)}</td>
              <td className="px-6 py-4 text-sm text-slate-500 font-medium">{payment.required_amount ? formatAmount(payment.required_amount) : '-'}</td>
              <td className="px-6 py-4 text-sm text-slate-600 dark:text-slate-400">{payment.month}</td>
              <td className="px-6 py-4 text-xs font-bold text-slate-500">{payment.method}</td>
              <td className="px-6 py-4 text-sm text-slate-500 dark:text-slate-500">
                {new Date(payment.date).toLocaleDateString('ar-EG')}
              </td>
              <td className="px-6 py-4">
                <div className="flex gap-2">
                  <button onClick={() => onEdit(payment)} className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors">
                    <Edit2 size={16} />
                  </button>
                  <button onClick={() => onDelete(payment.id)} className="p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-colors">
                    <Trash2 size={16} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {payments.length === 0 && (
        <div className="text-center py-12 text-slate-500">لا يوجد سجل مدفوعات حالياً.</div>
      )}
    </div>
  </div>
);

const StatusBadge = ({ status, daysOverdue }: { status: string, daysOverdue: number }) => {
  if (status === 'confirmed') {
    return (
      <span className="px-3 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-full text-xs font-bold">
        تم الدفع
      </span>
    );
  }
  
  if (daysOverdue > 5) {
    return (
      <span className="px-3 py-1 bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-full text-xs font-bold">
        متأخر {daysOverdue} يوم
      </span>
    );
  }
  
  return (
    <span className="px-3 py-1 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 rounded-full text-xs font-bold">
      معلق
    </span>
  );
};
